/**
 * 
 */
/**
 * @author Usuario
 *
 */
module dbconnect_master {
	requires java.sql;
}